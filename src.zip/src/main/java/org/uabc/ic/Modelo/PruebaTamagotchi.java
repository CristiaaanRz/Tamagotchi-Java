package org.uabc.ic.Modelo;

public class PruebaTamagotchi {

    public static void main(String[] args) {

        // Crear nuestro perro
        Perro perro = new Perro("Ramiro");

        // Mostrar estado inicial
        System.out.println("=== ESTADO INICIAL ===");
        System.out.println(perro.mostrarEstado());

        // Primera accion: jugar
        System.out.println("\n=== JUGANDO ===");
        perro.jugar(TipoJuego.PELOTA);
        System.out.println(perro.mostrarEstado());

        // Segunda accion: alimentar
        System.out.println("\n=== ALIMENTANDO ===");
        perro.alimentar(TipoAlimento.CROQUETAS);
        System.out.println(perro.mostrarEstado());

        // Tercera accion: dormir
        System.out.println("\n=== DURMIENDO ===");
        perro.dormir();
        System.out.println(perro.mostrarEstado());

        // Comportamiento exclusivo
        System.out.println("\n=== COMPORTAMIENTO UNICO ===");
        perro.realizarComportamientoUnico();

        System.out.println("Ladridos: " + perro.getNivelLadridos());
    }
}